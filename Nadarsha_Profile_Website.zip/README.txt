NADARSHA N — Personal Profile Website

Files:
- index.html: one-page professional profile
- assets/profile-photo.png: selected profile portrait

Privacy:
- Phone number and email address are intentionally not displayed.
- Instagram and Facebook links are public links supplied by the profile owner.

Publish:
1. Upload the contents of this folder to a static website host (for example, GitHub Pages or Netlify).
2. Make sure index.html is at the published site's root.
3. After the site is live, add its URL in Google Search Console and request indexing.
Google indexing and display in search results are not guaranteed.
